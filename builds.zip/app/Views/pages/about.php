<?= $this->extend('layout/template'); ?>

<?= $this->section('content'); ?>

<div class="contaiener">
    <div class="row">
        <div class="col">
            <h1>About Me</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident, quos nobis, eos eaque sint soluta vero, ab ipsum quam quibusdam magni odit corrupti at tempore neque minima exercitationem. Odio, porro.</p>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>